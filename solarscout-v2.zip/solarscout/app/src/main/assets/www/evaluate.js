// 屋頂評估與收益計算（純函式，可在 Node 測試）
(function (root) {
  const PING = 3.30579;            // 1 坪 = 3.30579 m²
  const DECAY = 0.006;             // 每年直線衰退 0.6%（固定）
  const YEARS = 20;
  const TOTAL_FACTOR = YEARS - DECAY * YEARS * (YEARS - 1) / 2; // 18.86
  const AVG_FACTOR = TOTAL_FACTOR / YEARS;                       // 0.943

  // 2025 年氣象署各地區日照時數（每日）
  const SUN = {
    雙北: 2.56, 宜蘭: 2.64, 花蓮: 2.8, 台東: 2.89, 桃園: 2.97, 新竹: 2.92, 苗栗: 3.37,
    台中: 3.42, 南投: 3.34, 彰化: 3.73, 雲林: 3.59, 嘉義: 3.6, 台南: 3.58, 高雄: 3.58, 屏東: 3.5
  };
  // Solar API 的縣市代碼
  const CODE = {
    TAO: '桃園', HSQ: '新竹', HSZ: '新竹', MIA: '苗栗', TPE: '雙北', NWT: '雙北', TPQ: '雙北', KEE: '雙北',
    ILA: '宜蘭', HUA: '花蓮', TTT: '台東', TXG: '台中', NAN: '南投', CHA: '彰化', YUN: '雲林',
    CYI: '嘉義', CYQ: '嘉義', TNN: '台南', KHH: '高雄', PIF: '屏東'
  };
  // 115 年屋頂型躉購費率（苗栗以北）
  const RATE_TIERS = [
    { min: 0, label: '1–10 kW' }, { min: 10, label: '10–20 kW' }, { min: 20, label: '20–50 kW' },
    { min: 50, label: '50–100 kW' }, { min: 100, label: '100–500 kW' }, { min: 500, label: '500 kW 以上' }
  ];

  const DEFAULTS = {
    minRoofPing: 14,      // 屋頂面積下限（坪）
    minKw: 7,             // 可裝容量下限（kW）
    minYield: 1000,       // 板子位置每 kW 年發電下限（Google 直流估算），低於的位置不排板
    maxGroundPing: 60,    // 建物投影上限（坪），超過視為非透天
    panelW: 445,          // 板子瓦數
    sun: { 桃園: 2.97, 新竹: 2.92, 苗栗: 3.37 },
    rates: [6.8754, 6.5777, 5.2087, 5.03, 4.6574, 4.4501],
    nearMargin: 0.85
  };

  function summarize(resp) {
    const sp = resp.solarPotential || {};
    const roof = sp.wholeRoofStats || {};
    const d = resp.imageryDate || {};
    return {
      id: resp.name,
      lat: resp.center && resp.center.latitude,
      lng: resp.center && resp.center.longitude,
      bbox: resp.boundingBox ? [
        resp.boundingBox.sw.latitude, resp.boundingBox.sw.longitude,
        resp.boundingBox.ne.latitude, resp.boundingBox.ne.longitude
      ] : null,
      roofM2: roof.areaMeters2 || 0,
      groundM2: roof.groundAreaMeters2 || 0,
      maxPanels: sp.maxArrayPanelsCount || 0,
      panelW: sp.panelCapacityWatts || 400,   // Google 排板用的瓦數，只用來換算遮蔭
      maxSun: sp.maxSunshineHoursPerYear || 0,
      configs: (sp.solarPanelConfigs || []).map(c => ({ n: c.panelsCount, kwh: c.yearlyEnergyDcKwh })),
      quality: resp.imageryQuality || '',
      imgDate: d.year ? `${d.year}-${String(d.month || 1).padStart(2, '0')}` : '',
      segments: (sp.roofSegmentStats || []).length,
      place: [resp.administrativeArea, resp.postalCode].filter(Boolean).join(' '),
      t: Date.now()
    };
  }

  // Google 從日照最好的位置開始排板；一路加到新加的板子位置日照低於門檻就停
  function shadePanels(b, minYield) {
    const gkw = (b.panelW || 400) / 1000;
    let prevN = 0, prevE = 0, rec = 0, recE = 0;
    for (const c of b.configs || []) {
      if (!(c.n > prevN)) continue;
      const perKw = (c.kwh - prevE) / (c.n - prevN) / gkw;
      if (perKw < minYield) break;
      rec = c.n; recE = c.kwh; prevN = c.n; prevE = c.kwh;
    }
    const first = (b.configs || [])[0];
    const yieldPerKw = rec ? recE / rec / gkw : (first && first.n ? first.kwh / first.n / gkw : 0);
    return { panels: rec, yieldPerKw };
  }

  // 片數與面積；手動劃的屋頂依面積比例分配整棟的結果
  function analyze(b, o, parent) {
    if (b.parent) {
      if (!parent) return { panels: 0, maxPanels: 0, yieldPerKw: 0, roofM2: b.groundM2, groundM2: b.groundM2, share: 0 };
      const pa = analyze(parent, o);
      const share = parent.groundM2 > 0 ? b.groundM2 / parent.groundM2 : 0;
      const slope = parent.groundM2 > 0 ? parent.roofM2 / parent.groundM2 : 1;
      return {
        panels: Math.floor(pa.panels * share + 1e-9),
        maxPanels: Math.floor(parent.maxPanels * share + 1e-9),
        yieldPerKw: pa.yieldPerKw, roofM2: b.groundM2 * slope, groundM2: b.groundM2, share
      };
    }
    const s = shadePanels(b, o.minYield);
    return { panels: s.panels, maxPanels: b.maxPanels, yieldPerKw: s.yieldPerKw, roofM2: b.roofM2, groundM2: b.groundM2 };
  }

  function normalize(t) { return String(t || '').replace(/臺/g, '台'); }
  function regionFromText(t) {
    t = normalize(t);
    if (/台北|新北|基隆/.test(t)) return '雙北';
    for (const k in SUN) if (k !== '雙北' && t.indexOf(k) >= 0) return k;
    return null;
  }
  function regionOf(b) {
    return regionFromText(b.county) || regionFromText(b.addr) || CODE[(b.place || '').split(' ')[0]] || null;
  }
  function sunFor(b, o) {
    const region = regionOf(b);
    const sun = (o && o.sun) || DEFAULTS.sun;
    if (region && sun[region] != null) return { region, hours: +sun[region], guessed: false };
    if (region && SUN[region] != null) return { region, hours: SUN[region], guessed: false };
    return { region: '新竹', hours: +(sun['新竹'] || SUN['新竹']), guessed: true };
  }

  function tierIndex(kw) {
    let i = 0;
    for (let k = 0; k < RATE_TIERS.length; k++) if (kw >= RATE_TIERS[k].min) i = k;
    return i;
  }
  function finance(kw, hours, o) {
    const rates = (o && o.rates) || DEFAULTS.rates;
    const first = kw * hours * 365;
    const i = tierIndex(kw);
    const rate = +rates[i];
    const avgKwh = first * AVG_FACTOR, totalKwh = first * TOTAL_FACTOR;
    return { firstKwh: first, avgKwh, totalKwh, rate, tier: RATE_TIERS[i].label, avgIncome: avgKwh * rate, totalIncome: totalKwh * rate };
  }

  function evaluate(b, opt, parent) {
    const o = Object.assign({}, DEFAULTS, opt || {});
    const a = analyze(b, o, parent);
    const pw = o.panelW / 1000;
    const kw = Math.round(a.panels * pw * 1000) / 1000;
    const maxKw = a.maxPanels * pw;
    const sun = sunFor(b, o);
    const m = {
      panels: a.panels, kw, maxPanels: a.maxPanels, maxKw,
      roofPing: a.roofM2 / PING, groundPing: a.groundM2 / PING,
      yieldPerKw: a.yieldPerKw, share: a.share
    };
    const fin = finance(kw, sun.hours, o);
    const out = (status, reasons) => ({ status, reasons, metrics: m, fin, sun });

    if (!b.parent && o.maxGroundPing > 0 && m.groundPing > o.maxGroundPing) {
      return out('big', [`建物投影 ${m.groundPing.toFixed(0)} 坪，超過 ${o.maxGroundPing} 坪，可能不是透天。如果是連棟透天，可以用「手動劃屋頂」劃出單戶`]);
    }
    const checks = [
      { ok: m.roofPing >= o.minRoofPing, ratio: m.roofPing / o.minRoofPing,
        fail: `屋頂 ${m.roofPing.toFixed(1)} 坪，未達 ${o.minRoofPing} 坪` },
      { ok: kw >= o.minKw, ratio: kw / o.minKw,
        fail: maxKw >= o.minKw
          ? `排除遮蔭位置後只能裝 ${kw.toFixed(2)} kW，未達 ${o.minKw} kW（不管遮蔭最多 ${maxKw.toFixed(2)} kW）`
          : `屋頂最多只能裝 ${maxKw.toFixed(2)} kW，未達 ${o.minKw} kW` }
    ];
    const failed = checks.filter(c => !c.ok);
    if (!failed.length) return out('pass', []);
    const near = failed.length === 1 && failed[0].ratio >= o.nearMargin;
    return out(near ? 'near' : 'fail', failed.map(c => c.fail));
  }

  // 幾何：pts 為 [[lng, lat], ...]
  function polyAreaM2(pts) {
    if (!pts || pts.length < 3) return 0;
    const lat0 = pts.reduce((s, p) => s + p[1], 0) / pts.length * Math.PI / 180;
    const kx = 111320 * Math.cos(lat0), ky = 110574;
    let s = 0;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], q = pts[(i + 1) % pts.length];
      s += p[0] * kx * q[1] * ky - q[0] * kx * p[1] * ky;
    }
    return Math.abs(s) / 2;
  }
  function pointInPoly(lng, lat, pts) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const xi = pts[i][0], yi = pts[i][1], xj = pts[j][0], yj = pts[j][1];
      if ((yi > lat) !== (yj > lat) && lng < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  }
  function centroid(pts) {
    return [pts.reduce((s, p) => s + p[0], 0) / pts.length, pts.reduce((s, p) => s + p[1], 0) / pts.length];
  }

  const api = { PING, DECAY, AVG_FACTOR, TOTAL_FACTOR, SUN, CODE, RATE_TIERS, DEFAULTS,
    summarize, shadePanels, analyze, regionFromText, regionOf, sunFor, finance, evaluate,
    polyAreaM2, pointInPoly, centroid };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SolarEval = api;
})(this);
