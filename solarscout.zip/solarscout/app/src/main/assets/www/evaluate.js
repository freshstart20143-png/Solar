// 屋頂評估邏輯（純函式，可在 Node 測試）
(function (root) {
  const PING = 3.30579; // 1 坪 = 3.30579 m²

  const DEFAULTS = {
    minRoofPing: 14,      // 屋頂面積下限（坪）
    minKw: 7,             // 可裝容量下限（kW）
    minYield: 1000,       // 每 kW 年發電下限（kWh/kW），低於視為遮蔭嚴重
    maxGroundPing: 60,    // 建物投影面積上限（坪），超過視為非透天（大樓、廠房）
    nearMargin: 0.85      // 達門檻 85% 以上算「接近」
  };

  // 把 Solar API buildingInsights 回應縮成要存的欄位
  function summarize(resp) {
    const sp = resp.solarPotential || {};
    const roof = sp.wholeRoofStats || {};
    const w = sp.panelCapacityWatts || 400;
    const configs = (sp.solarPanelConfigs || []).map(c => ({
      n: c.panelsCount, kwh: c.yearlyEnergyDcKwh
    }));
    const d = resp.imageryDate || {};
    return {
      id: resp.name,
      lat: resp.center && resp.center.latitude,
      lng: resp.center && resp.center.longitude,
      bbox: resp.boundingBox ? [
        resp.boundingBox.sw.latitude, resp.boundingBox.sw.longitude,
        resp.boundingBox.ne.latitude, resp.boundingBox.ne.longitude
      ] : null,
      roofM2: roof.areaMeters2 || 0,
      groundM2: roof.groundAreaMeters2 || 0,
      maxPanels: sp.maxArrayPanelsCount || 0,
      panelW: w,
      maxSun: sp.maxSunshineHoursPerYear || 0,
      medianSun: roof.sunshineQuantiles ? roof.sunshineQuantiles[5] : null,
      configs: configs,
      quality: resp.imageryQuality || '',
      imgDate: d.year ? `${d.year}-${String(d.month || 1).padStart(2, '0')}` : '',
      segments: (sp.roofSegmentStats || []).length,
      place: [resp.administrativeArea, resp.postalCode].filter(Boolean).join(' '),
      t: Date.now()
    };
  }

  // 判斷是否適合：回傳 { status: pass|near|fail|big, reasons[], metrics }
  function evaluate(b, opt) {
    const o = Object.assign({}, DEFAULTS, opt || {});
    const roofPing = b.roofM2 / PING;
    const groundPing = b.groundM2 / PING;
    const maxKw = b.maxPanels * b.panelW / 1000;
    // 找出第一個達到最低容量的排列方式，用它的每 kW 年發電當遮蔭指標
    let cfg = null;
    for (const c of b.configs) {
      if (c.n * b.panelW / 1000 >= o.minKw) { cfg = c; break; }
    }
    if (!cfg && b.configs.length) cfg = b.configs[b.configs.length - 1];
    const cfgKw = cfg ? cfg.n * b.panelW / 1000 : 0;
    const yieldPerKw = cfg && cfgKw ? cfg.kwh / cfgKw : 0;

    const m = {
      roofPing, groundPing, maxKw, cfgKw,
      cfgKwh: cfg ? cfg.kwh : 0,
      yieldPerKw,
      sunRatio: b.maxSun ? yieldPerKw / b.maxSun : 0
    };

    if (o.maxGroundPing > 0 && groundPing > o.maxGroundPing) {
      return { status: 'big', reasons: [`建物投影 ${groundPing.toFixed(0)} 坪，超過 ${o.maxGroundPing} 坪，可能不是透天`], metrics: m };
    }

    const checks = [
      { ok: roofPing >= o.minRoofPing, ratio: roofPing / o.minRoofPing,
        fail: `屋頂 ${roofPing.toFixed(1)} 坪，未達 ${o.minRoofPing} 坪` },
      { ok: maxKw >= o.minKw, ratio: maxKw / o.minKw,
        fail: `最多可裝 ${maxKw.toFixed(1)} kW，未達 ${o.minKw} kW` },
      { ok: yieldPerKw >= o.minYield, ratio: yieldPerKw / o.minYield,
        fail: `每 kW 年發電 ${Math.round(yieldPerKw)} 度，低於 ${o.minYield} 度（遮蔭或朝向差）` }
    ];
    const failed = checks.filter(c => !c.ok);
    if (!failed.length) return { status: 'pass', reasons: [], metrics: m };
    const near = failed.length === 1 && failed[0].ratio >= o.nearMargin;
    return { status: near ? 'near' : 'fail', reasons: failed.map(c => c.fail), metrics: m };
  }

  const api = { PING, DEFAULTS, summarize, evaluate };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SolarEval = api;
})(this);
