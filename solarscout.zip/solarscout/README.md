# 屋頂光電探勘

桃竹苗透天屋頂光電篩選 App（安卓自用）。

- 底圖：內政部國土測繪中心正射影像
- 屋頂、遮蔭、可裝容量：Google Solar API（Building Insights，每月前 10,000 次免費）
- 建物清單：OpenStreetMap，資料不全時可改用格點掃描

## 篩選條件（App 內可調）
- 屋頂面積 ≥ 14 坪
- 可裝容量 ≥ 7 kW
- 每 kW 年發電 ≥ 1000 度（低於代表遮蔭嚴重）
- 建物投影 ≤ 60 坪（排除大樓、廠房）
- 手動標記疑似頂加者排除

## 產生 APK
推到 GitHub 的 main 分支後，Actions 會自動建置，APK 出現在 Releases。
